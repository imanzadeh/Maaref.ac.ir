<?php $__env->startSection('content'); ?>

    <div class="page-wrapper chiller-theme toggled">
        <a id="show-sidebar" class="btn btn-sm btn-dark" href="#">
            <i class="fas fa-angle-double-left"></i>
        </a>

    <?php echo $__env->make('layouts.dashboard_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- sidebar-wrapper  -->
        <main class="page-content">
            <div class="container-fluid">

                <div class="row">
                    <div class="form-group col-md-12">
                        <section>
                            <div class="container">
                                <h2 class="main-content-title"> خوش آمدید </h2>

                                <p>
                                    <h4>نکات:</h4>
                                    <ul>
                                        <li>نکته 1: لطفا قبل از استفاده از سامانه فایل راهنما را مطالعه کنید.</li>
                                        <li>نکته 2: در صورت مشکل می توانید با شماره تلفن 02532110488 تماس حاصل فرمایید.</li>
                                    </ul>
                                </p>
                            </div>
                        </section>
                    </div>
                </div>
            </div>

        </main>
        <!-- page-content" -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Seamlessly_Git\Maaref.ac.ir\resources\views/home.blade.php ENDPATH**/ ?>