<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row margin-top-50">
            <div class="col-md-12">
                <h3 class="text-center professor_list_title">گزارش براساس...</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 offset-4">
                <form method="post" action="<?php echo e(route('paymentsCase.store')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label class="control-label"><strong>عنوان</strong></label>
                        <select name="case_id" class="form-control">
                            <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($case->id); ?>"><?php echo e($case->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>از تاریخ:</label>
                        <input type="text" name="start_text" id="start_text"
                               class="form-control DatePicker-input" placeholder="انتخاب تاریخ"
                               aria-label="date1" aria-describedby="date1" autocomplete="off">
                        <input type="hidden" id="start_date" name="start_date"
                               class="form-control" placeholder="Persian Calendar Date"
                               aria-label="date11" aria-describedby="date11" autocomplete="off">
                        <div class="input-group-prepend">
                                    <span class="input-group-text cursor-pointer DatePicker-icon" id="date1">
                                        <i class="fas fa-calendar-alt"></i>
                                    </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>تا تاریخ:</label>
                        <input type="text" name="end_text" id="end_text"
                               class="form-control DatePicker-input" placeholder="انتخاب تاریخ"
                               aria-label="date2" aria-describedby="date2" autocomplete="off">
                        <input type="hidden" id="end_date" name="end_date"
                               class="form-control" placeholder="Persian Calendar Date"
                               aria-label="date12" aria-describedby="date12" autocomplete="off">
                        <div class="input-group-prepend">
                            <span class="input-group-text cursor-pointer DatePicker-icon" id="date2">
                                <i class="fas fa-calendar-alt"></i>
                            </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="submit"  value="جستجو" class="btn btn-success col-md-12"/>
                    </div>
                </form>
                <?php if($errors->any()): ?>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="text-danger">
                                <?php echo e($error); ?>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <div class="row">
            <table class="table table-bordered table-striped <?php echo e(count($PaymentList) > 0 ? 'datatable' : ''); ?> dt-select">
                <thead>
                <tr>
                    <th>نام</th>
                    <th>نام خانوادگی</th>
                    <th>کد ملی</th>
                    <th>شماره موبایل</th>
                    <th>شماره سریال</th>
                    <th>شماره خرید</th>
                    <th>شماره تراکنش</th>
                    <th>شماره مرجع</th>
                    <th>هزینه</th>
                    <th>تاریخ پرداخت</th>

                </tr>
                </thead>

                <tbody>
                <?php if(count($PaymentList) > 0): ?>
                    <?php $__currentLoopData = $PaymentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($payment->name); ?></td>
                            <td><?php echo e($payment->family); ?></td>
                            <td><?php echo e($payment->code_meli); ?></td>
                            <td><?php echo e($payment->mobile); ?></td>
                            <td><?php echo e($payment->serial_number); ?></td>
                            <td><?php echo e($payment->OrderId); ?></td>
                            <td><?php echo e($payment->TraceNo); ?></td>
                            <td><?php echo e($payment->RefNo); ?></td>
                            <td><?php echo e($payment->price); ?></td>
                            <td><?php echo e($payment->date); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9">موردی یافت نشد</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('#date1').MdPersianDateTimePicker({
                targetTextSelector: '#start-text',
                targetDateSelector: '#start-date',
                enableTimePicker: false,
                dateFormat: 'yyyy-MM-dd',
                textFormat: 'yyyy-MM-dd ',
            });

            $('#date2').MdPersianDateTimePicker({
                targetTextSelector: '#end-text',
                targetDateSelector: '#end-date',
                enableTimePicker: false,
                dateFormat: 'yyyy-MM-dd',
                textFormat: 'yyyy-MM-dd ',
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Seamlessly_Git\Maaref.ac.ir\resources\views/payments/reports.blade.php ENDPATH**/ ?>