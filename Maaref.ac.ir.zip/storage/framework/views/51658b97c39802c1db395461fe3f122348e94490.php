<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row margin-top-50">
            <div class="col-md-12">
                <h3 class="text-center professor_list_title"> لیست موارد پرداخت</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8 offset-2">
                <p>
                    <a class="btn btn-primary" href="<?php echo e(route('paymentsCase.create')); ?>">جدید</a>
                </p>
                <table class="table float-right">
                    <thead>
                    <tr>
                        <th>عنوان</th>
                        <th>شماره پرداخت</th>
                        <th>هزینه</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        
                                            <?php echo e($case->title); ?>

                                        
                                    </td>

                                    <td>
                                        <?php echo e($case->PaymentID); ?>

                                    </td>

                                    <td>
                                        <?php echo e($case->cost); ?>

                                    </td>

                                    <td>
                                <a href="<?php echo e(route('paymentsCase.delete',[$case->id])); ?>" class="btn btn-danger">
                                    حذف
                                </a>
                                <a href="<?php echo e(route('paymentsCase.edit',[$case->id])); ?>" class="btn btn-warning">
                                    ویرایش
                                </a>
                                    </td>
                                </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Seamlessly_Git\Maaref.ac.ir\resources\views/payments/index.blade.php ENDPATH**/ ?>