<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="form-group col-md-12">
            <!-- Tabs -->
            <section id="tabs">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="text-center professor_list_title">لیست اساتید هیأت علمی </h3>
                        </div>
                    </div>
                    <div class="row">
                        
                            <?php $__currentLoopData = $professors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-lg-4 col-md-6">
                                    <a href="<?php echo e(route('management.professor_edit_resumes', [$pro->id, 0])); ?>">
                                        <div class="row professor_div">
                                            <div class="col-lg-5 col-5 text-center">
                                                <img src="/images/UsersPic/<?php echo e($pro->pic); ?>"
                                                     class="professor_pic img-responsive">
                                            </div>
                                            <div class="col-lg-7 col-7" style="padding: 0">
                                                <label class="professor_name"> <?php echo e($pro->FirstName . " ". $pro->LastName); ?> </label>

                                                <label class="professor_email">  <?php echo e($pro->email); ?> </label>
                                                <label> <strong>گروه آموزشی: </strong> <?php echo e($pro->professor->getGroup($pro->professor->group_id)->title); ?> </label>
                                                <label> <?php echo e($pro->professor->getLevel($pro->professor->level_id)); ?> </label>
                                            </div>
                                        </div>
                                    </a>
                                </div>

                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <a href="<?php echo e(route('management.Add_Professor_Form')); ?>">
                                <div class="row professor_div">
                                    <div class="col-lg-5 col-5 text-center">
                                        <img src="/images/UsersPic/plus.png" class="professor_pic img-responsive" style="background: #212529;">
                                    </div>
                                </div>
                            </a>
                        </div>
                        
                    </div>
                </div>
            </section>
            <!-- ./Tabs -->
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\Seamlessly_Git\Maaref.ac.ir\resources\views/members/ProfessorsListManagement.blade.php ENDPATH**/ ?>