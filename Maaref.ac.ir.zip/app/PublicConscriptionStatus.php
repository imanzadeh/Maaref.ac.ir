<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PublicConscriptionStatus extends Model
{
    //
}
