<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Resumes extends Model
{
    protected $fillable = ['title'];
}
