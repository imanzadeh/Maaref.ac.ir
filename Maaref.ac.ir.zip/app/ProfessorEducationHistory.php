<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProfessorEducationHistory extends Model
{
    //
}
