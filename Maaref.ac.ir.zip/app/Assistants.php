<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Assistants extends Model
{
    //
}
