<?php

namespace App\Http\Controllers;

use App\MaarefLessons;
use Illuminate\Http\Request;

class MaarefLessonsController extends Controller
{

    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(MaarefLessons $maarefLessons)
    {
        //
    }

    public function edit(MaarefLessons $maarefLessons)
    {
        //
    }

    public function update(Request $request, MaarefLessons $maarefLessons)
    {
        //
    }

    public function destroy(MaarefLessons $maarefLessons)
    {
        //
    }
}
