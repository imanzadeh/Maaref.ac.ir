<?php

namespace App\Http\Controllers;

use App\Professors;
use App\Scientific_Group;
use App\Scientific_Level;
use Illuminate\Http\Request;

class ProfessorsController extends Controller
{

    public function index()
    {
        //
    }

    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        //
    }

    public function show(Professors $professors)
    {
        //
    }

    public function edit(Professors $professors)
    {
        //
    }

    public function update(Request $request, Professors $professors)
    {
        //
    }

    public function destroy(Professors $professors)
    {
        //
    }
}
