<?php

namespace App\Http\Controllers;

use App\ProfessorEducationHistory;
use Illuminate\Http\Request;

class ProfessorEducationHistoryController extends Controller
{
    public function index()
    {
        //
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show(ProfessorEducationHistory $professorEducationHistory)
    {
        //
    }

    public function edit(ProfessorEducationHistory $professorEducationHistory)
    {
        //
    }

    public function update(Request $request, ProfessorEducationHistory $professorEducationHistory)
    {
        //
    }

    public function destroy(ProfessorEducationHistory $professorEducationHistory)
    {
        //
    }
}
